export interface RawData {
    data: any;
    
    // Add more properties as needed
  }